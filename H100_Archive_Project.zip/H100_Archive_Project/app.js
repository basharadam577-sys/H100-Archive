const menuBtn = document.getElementById('menuBtn');
const mainNav = document.getElementById('mainNav');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const archiveGrid = document.getElementById('archiveGrid');
const emptyState = document.getElementById('emptyState');
const statusLabel = document.getElementById('status');

document.getElementById('year').textContent = new Date().getFullYear();
menuBtn?.addEventListener('click', () => mainNav.classList.toggle('active'));
mainNav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => mainNav.classList.remove('active')));

function filterCards() {
  const term = (searchInput.value || '').trim().toLocaleLowerCase();
  const category = categoryFilter.value;
  let visible = 0;
  archiveGrid.querySelectorAll('.archive-card').forEach(card => {
    const text = card.textContent.toLocaleLowerCase();
    const cardCategory = card.dataset.category || card.querySelector('.card-category')?.textContent || '';
    const matches = text.includes(term) && (!category || cardCategory === category);
    card.hidden = !matches;
    if (matches) visible++;
  });
  emptyState.hidden = visible > 0;
}
searchInput?.addEventListener('input', filterCards);
categoryFilter?.addEventListener('change', filterCards);

const backToTop = document.getElementById('backToTop');
window.addEventListener('scroll', () => {
  backToTop.style.display = window.scrollY > 300 ? 'block' : 'none';
});
backToTop?.addEventListener('click', () => window.scrollTo({top: 0, behavior: 'smooth'}));

// ربط Supabase غير مفعّل في هذه النسخة. لا تضع مفتاح service_role داخل ملفات الموقع.
